Gullible
========================================================
In this short and simple program, you can learn the secret and subtle art of keeping a gullible person busy for hours. 

Sample Output
========================================================

![Sample output Gullible](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C32-Project-32-Gullible/gullible_sample_output-PNG.png)

