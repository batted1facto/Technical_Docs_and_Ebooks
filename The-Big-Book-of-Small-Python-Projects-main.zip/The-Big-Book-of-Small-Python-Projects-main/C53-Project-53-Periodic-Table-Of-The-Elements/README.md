Periodic Table Of The Elements
========================================================

This program presents the periodic table of the elements and lets the player access additional information about each element, such as its atomic number, symbol, melting point, and so on. 

Sample Output
========================================================

![Sample output Periodic Table Of The Elements](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C53-Project-53-Periodic-Table-Of-The-Elements/periodictable_sample_output.PNG)
