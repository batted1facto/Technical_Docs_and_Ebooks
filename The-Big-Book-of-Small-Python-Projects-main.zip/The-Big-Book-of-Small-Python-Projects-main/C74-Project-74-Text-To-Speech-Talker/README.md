Text-To-Speech Talker
========================================================

This program demonstrates the use of the pyttsx3 third-party module. Any message you enter will be spoken out loud by your operating system’s text-to-speech capabilities.

Sample Output
========================================================

Tested on Linux Mint 20.3 Una.

![Sample output Text-To-Speech Talker](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C74-Project-74-Text-To-Speech-Talker/Text-To-Speech-Talker-sample-output.png)



Have a look at this source: 
https://stackoverflow.com/questions/61762106/installing-pyttsx3-on-linux-mint

