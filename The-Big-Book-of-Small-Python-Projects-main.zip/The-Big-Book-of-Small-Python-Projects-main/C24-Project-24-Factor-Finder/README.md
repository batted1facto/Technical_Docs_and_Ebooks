Factor Finder
========================================================
A number’s factors are any two other num- bers that, when multiplied with each other, produce the number.

Sample Output
========================================================

![Sample output Factor Finder](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C24-Project-24-Factor-Finder/factorfinder_sample_output.PNG)

