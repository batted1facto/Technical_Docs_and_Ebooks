Rainbow
========================================================

This program continuously prints the same rainbow pattern. 

Sample Output
========================================================

![Sample output Rainbow](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C58-Project-58-Rainbow/rainbow_sample_output.PNG)
