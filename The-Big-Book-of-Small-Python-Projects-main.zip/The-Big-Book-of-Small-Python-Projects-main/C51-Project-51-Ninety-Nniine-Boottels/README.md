Ninety-Nniine Boottels
========================================================

In this version of the song “Ninety-Nine Bottles,” the program introduces small imperfections in each stanza by either removing a letter, swapping the casing of a letter, transposing two letters, or doubling a letter.

Sample Output
========================================================

![Sample output Ninety-Nniine Boottels](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C51-Project-51-Ninety-Nniine-Boottels/ninetyninebottles2_sample_output.PNG)
