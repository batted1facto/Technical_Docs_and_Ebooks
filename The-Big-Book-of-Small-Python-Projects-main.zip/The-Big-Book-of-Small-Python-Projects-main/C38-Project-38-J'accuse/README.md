J'accuse
========================================================

You are the world-famous detective Mathilde Camus. Zophie the cat has gone missing, and you must sift through the clues. 

Sample Output
========================================================

![Sample output J'accuse](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C38-Project-38-J'accuse/jaccuse_sample_output.PNG)

