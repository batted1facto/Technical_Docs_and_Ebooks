Mancala
========================================================

The board game Mancala is a "seed-sowing" game in which two players select pockets of seeds to spread across the other pockets on the board while trying to collect as many in their store as possible.

Sample Output
========================================================

![Sample output Mancala](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C43-Project-43-Mancala/mancala_sample_output.PNG)

