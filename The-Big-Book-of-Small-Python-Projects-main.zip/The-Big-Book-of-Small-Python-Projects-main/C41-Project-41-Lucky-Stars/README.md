Lucky Stars
========================================================

In this push-your-luck game, you roll dice to collect stars. The more you roll, the more stars you can get, but if you get three skulls you lose everything!

Sample Output
========================================================

![Sample output Lucky Stars](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C41-Project-41-Lucky-Stars/luckystars_sample_output.PNG)

