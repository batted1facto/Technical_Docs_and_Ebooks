Million Dice Roll Statistics Simulator
========================================================

In this program, you tell the computer to roll N dice one million times and remember the results. It then displays the percentage chance of each sum.

Sample Output
========================================================

![Sample output Million Dice Roll Statistics Simulator](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C46-Project-46-Million-Dice/milliondicestats_sample_output.PNG)

