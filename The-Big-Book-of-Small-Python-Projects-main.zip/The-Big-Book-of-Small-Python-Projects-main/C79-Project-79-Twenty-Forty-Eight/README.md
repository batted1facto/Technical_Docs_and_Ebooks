Twenty Forty-Eight
========================================================

In 2048, you must merge numbers on a 4 × 4 board to clear them from the screen. 

Sample Output
========================================================

![Sample output Twenty Forty-Eight](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C79-Project-79-Twenty-Forty-Eight/twentyfortyeight_sample_output.PNG)
