Sliding Tile Puzzle
========================================================
This classic puzzle relies on a 4 × 4 board with 15 numbered tiles and one free space.

Sample Output
========================================================

![Sample output Sliding Tile Puzzle)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C68-Project-68-Sliding-Tile-Puzzle/slidingtilepuzzle_sample_output.PNG)
