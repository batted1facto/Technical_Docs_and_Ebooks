Numeral Systems Counters
========================================================

This program computes binary and hexadecimal representations of a number.

Sample Output
========================================================

![Sample output Numeral Systems Counters](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C52-Project-52-Numeral-Systems-Counters/numeralsystems_sample_output.PNG)
