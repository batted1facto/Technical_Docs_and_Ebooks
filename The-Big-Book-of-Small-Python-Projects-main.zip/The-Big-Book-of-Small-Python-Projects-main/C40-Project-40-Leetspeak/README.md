
Leetspeak
========================================================

This word program automatically converts your text with numbers. 

Sample Output
========================================================

![Sample output Leetspeak](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C40-Project-40-Leetspeak/leetspeak_sample_output.PNG)

