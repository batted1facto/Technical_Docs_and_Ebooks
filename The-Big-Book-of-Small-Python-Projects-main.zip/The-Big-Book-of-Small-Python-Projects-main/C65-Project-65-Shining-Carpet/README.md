Shining Carpet
========================================================

The short program in this project, similar to Project 35, "Hex Grid," prints repetitive pattern on the screen.

Sample Output
========================================================

![Sample output Shining Carpet)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C65-Project-65-Shining-Carpet/shining_carpet_sample_output.PNG)
