

Hangman and Guillotine
========================================================
This classic word game has the player guess the letters to a secret word. 

Sample Output
========================================================

![Sample output Hangman and Guillotine](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C34-Project-34-Hangman-and-Guillotine/hangman_sample_output.PNG)

