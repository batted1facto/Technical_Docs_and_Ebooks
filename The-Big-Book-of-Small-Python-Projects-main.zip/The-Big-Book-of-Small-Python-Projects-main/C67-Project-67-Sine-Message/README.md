Sine Message
========================================================

This program displays a message of the user’s choice in a wavy pattern as the text scrolls up. 

Sample Output
========================================================

![Sample output Sine Message)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C67-Project-67-Sine-Message/sinemessage_sample_output.PNG)
