
Fast Draw
========================================================
This program tests your reaction speed.

Sample Output
========================================================

![Sample output Fast Draw](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C25-Project-25-Fast-Draw/fastdraw_sample_output.PNG)

