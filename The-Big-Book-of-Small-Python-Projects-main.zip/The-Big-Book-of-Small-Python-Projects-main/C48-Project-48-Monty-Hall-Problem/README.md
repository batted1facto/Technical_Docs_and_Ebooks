Monty Hall Problem
========================================================

The Monty Hall Problem illustrates a surprising fact of probability. 


Sample Output
========================================================

![Sample output Monty Hall Problem](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C48-Project-48-Monty-Hall-Problem/montyhall_sample_output.PNG)

