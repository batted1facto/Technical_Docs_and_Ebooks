Ninety-Nine Bottles
========================================================

"Ninety-Nine Bottles" is a folk song of undetermined origin known for its length and repetitiveness. 


Sample Output
========================================================

![Sample output Ninety-Nine Bottles](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C50-Project-50-Ninety-Nine-Bottles/ninety_nine_bottles_sample_output.PNG)

