Rotating Cube
========================================================

This project features an animation of a 3D cube rotating using trigonometric functions. 

Sample Output
========================================================

![Sample output Rotating Cube)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C62-Project-62-Rotating-Cube/rotatingcube_sample_output.PNG)
