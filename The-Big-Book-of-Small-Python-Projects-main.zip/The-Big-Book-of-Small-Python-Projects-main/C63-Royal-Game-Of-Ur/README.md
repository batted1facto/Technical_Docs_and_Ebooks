Royal Game Of Ur
========================================================

Two players each begin with seven tokens in their home, and the first player to move all seven to the goal is the winner.

Sample Output
========================================================

![Sample output Royal Game Of Ur)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C63-Royal-Game-Of-Ur/royal_game_of_ur_sample_output.PNG)
