Rot13 Cipher
========================================================

The ROT13 cipher, one of the simplest encryption algorithms, stands for "rotate 13 spaces."

Sample Output
========================================================

![Sample output Rot13 Cipher)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C61-Project-61-Rot13-Cipher/rot13cipher_sample_output.PNG)
