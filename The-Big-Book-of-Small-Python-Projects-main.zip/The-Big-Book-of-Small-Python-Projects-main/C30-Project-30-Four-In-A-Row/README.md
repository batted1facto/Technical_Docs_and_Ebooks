Four In A Row 
========================================================
In this classic tile-dropping board game for two players, you must try to get four of your tiles in a row horizontally, vertically, or diagonally, while preventing your opponent from doing the same.

Sample Output
========================================================

![Sample output Four In A Row](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C30-Project-30-Four-In-A-Row/fourinarow_sample_output.PNG)
