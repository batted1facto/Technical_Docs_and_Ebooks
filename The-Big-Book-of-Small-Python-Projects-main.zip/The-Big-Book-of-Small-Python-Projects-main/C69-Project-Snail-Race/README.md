Snail Race
========================================================

This program makes use of two data structures, stored in two variables: snailNames is a list of strings of each snail’s name, and snailProgress is a dictionary whose keys are the snails' names and whose values are integers representing how many spaces the snails have moved.

Sample Output
========================================================

![Sample output Snail Race)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C69-Project-Snail-Race/snailrace_sample_output.PNG)
