Three-Card Monte
========================================================

This program shows the three cards and then quickly describes a series of swaps.

Sample Output
========================================================

![Sample output Three-Card Monte](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C75-Project-75-Three-Card-Monte/threecardmonte_sample_output.PNG)
