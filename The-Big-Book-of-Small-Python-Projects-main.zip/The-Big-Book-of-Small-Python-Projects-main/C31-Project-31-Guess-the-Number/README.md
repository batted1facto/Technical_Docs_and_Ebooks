Guess the Number
========================================================
In this game, the computer thinks of a random number between 1 and 100. The player has 10 chances to guess the number. 

Sample Output
========================================================

![Sample output Guess the Number](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C31-Project-31-Guess-the-Number/guess_the_number_sample_output.PNG)

