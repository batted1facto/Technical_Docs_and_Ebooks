Multiplication Table
========================================================

This program generates a multiplication table from 0 × 0 to 12 × 12. 


Sample Output
========================================================

![Sample output Multiplication Table](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C49-Project-49-Multiplication-Table/multiplication_table_sample_output.PNG)

