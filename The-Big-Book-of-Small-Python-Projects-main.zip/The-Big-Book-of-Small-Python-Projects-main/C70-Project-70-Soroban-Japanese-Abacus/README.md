Soroban Japanese Abacus
========================================================

Each column in the soroban represents a different digit. The rightmost column is the ones place, the column to its left is the tens place, the column to the left of that is the hundreds place, and so on. 

Sample Output
========================================================

![Sample output Soroban Japanese Abacus)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C70-Project-70-Soroban-Japanese-Abacus/soroban_sample_output.PNG)
