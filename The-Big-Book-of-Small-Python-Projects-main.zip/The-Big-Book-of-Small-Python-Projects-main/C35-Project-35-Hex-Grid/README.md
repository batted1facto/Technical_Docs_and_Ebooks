Hex Grid
========================================================
This short program produces a tessellated image of a hexagonal grid, similar to chicken wire. 

Sample Output
========================================================

![Sample output Hex Grid](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C35-Project-35-Hex-Grid/hexgrid_sample_output.PNG)

