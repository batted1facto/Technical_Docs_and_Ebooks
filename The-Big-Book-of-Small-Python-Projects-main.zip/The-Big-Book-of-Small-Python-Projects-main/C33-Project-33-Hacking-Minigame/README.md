
Hacking Minigame
========================================================
In this game, the player must hack a com- puter by guessing a seven-letter word used as the secret password. 

Sample Output
========================================================

![Sample output Hacking Minigame](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C33-Project-33-Hacking-Minigame/Hacking-Minigame_sample_output.PNG)

