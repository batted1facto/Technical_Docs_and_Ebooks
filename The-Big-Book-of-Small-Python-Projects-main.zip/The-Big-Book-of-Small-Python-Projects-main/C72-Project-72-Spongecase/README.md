Spongecase
========================================================

This short program uses the upper() and lower() string methods to convert your message into “spongecase.” 

Sample Output
========================================================

![Sample output Spongecase)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C72-Project-72-Spongecase/spongecase_sample_output.PNG)
