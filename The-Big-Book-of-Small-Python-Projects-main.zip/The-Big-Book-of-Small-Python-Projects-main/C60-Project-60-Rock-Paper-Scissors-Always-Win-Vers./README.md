Rock Paper Scissors (Always-Win Version)
========================================================

This variant of Rock Paper Scissors is identical to Project 59, "Rock Paper Scissors," except the player will always win. 

Sample Output
========================================================

![Sample output Rock Paper Scissors (Always-Win Version)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C60-Project-60-Rock-Paper-Scissors-Always-Win-Vers./rockpaperscissorsalwayswin_sample_output.PNG)
