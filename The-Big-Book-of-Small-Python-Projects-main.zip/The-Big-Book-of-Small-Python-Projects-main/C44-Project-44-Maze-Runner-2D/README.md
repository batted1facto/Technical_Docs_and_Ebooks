Maze Runner 2D
========================================================

This two-dimensional maze runner shows the player a top-down, bird’s-eye view of a maze file. Using the WASD keys, the player can move up, left, down, and right, respectively, to navigate the @ symbol toward the exit marked by the X character.

Sample Output
========================================================

![Sample output Maze Runner 2D](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C44-Project-44-Maze-Runner-2D/mazerunner_2d_sample_output.PNG)

