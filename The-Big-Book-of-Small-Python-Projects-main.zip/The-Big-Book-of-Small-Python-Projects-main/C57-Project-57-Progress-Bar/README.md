Progress Bar
========================================================

A progress bar is a visual element that shows how much of a task has been completed.

Sample Output
========================================================

![Sample output Progress Bar](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C57-Project-57-Progress-Bar/progressbar_sample_output.PNG)
