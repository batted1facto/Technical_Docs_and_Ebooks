Pig Latin
========================================================

Pig Latin is a word game that transforms English words into a parody of Latin.

Sample Output
========================================================

![Sample output Pig Latin](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C54-Project-54-Pig-Latin/piglatin_sample_output.PNG)
