Prime Numbers
========================================================

This program finds prime numbers through brute-force calculation.

Sample Output
========================================================

![Sample output Prime Numbers](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C56-Project-56-Prime-Numbers/primenumbers_sample_output.PNG)
