Magic Fortune Ball
========================================================

The Magic Fortune Ball can predict the future and answer your yes/no questions with 100 percent accuracy using the power of Python’s random number module.

Sample Output
========================================================

![Sample output Magic Fortune Ball](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C42-Project-42-Magic-Fortune-Ball/magicfortuneball_sample_output.PNG)

