Sudoku Puzzle
========================================================
The Sudoku board is a 9 × 9 grid in which the player must place the digits 1 to 9 once, and only once, in each row, column, and 3 × 3 subgrid. 

Sample Output
========================================================

![Sample output Sudoku Puzzle](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C73-Project-73-Sudoku-Puzzle/sudoku_sample_output.PNG)
