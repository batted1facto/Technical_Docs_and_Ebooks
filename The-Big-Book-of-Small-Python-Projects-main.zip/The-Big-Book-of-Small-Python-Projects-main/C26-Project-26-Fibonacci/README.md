
Fibonacci
========================================================
The Fibonacci sequence is a mathematical pattern. The sequence begins with 0 and 1, and the next number is always the sum of the previous two numbers. This program lets you calculate the sequence as high as you are willing to go.

Sample Output
========================================================

![Sample output Fibonacci](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C26-Project-26-Fibonacci/fibonacci_sample_output.PNG)

