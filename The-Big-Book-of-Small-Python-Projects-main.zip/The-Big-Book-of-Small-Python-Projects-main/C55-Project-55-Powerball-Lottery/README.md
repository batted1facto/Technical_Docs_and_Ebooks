Powerball Lottery
========================================================

You can pick six numbers: five drawn from 1 to 69, and a sixth “Powerball” number drawn from 1 to 26. 

Sample Output
========================================================

![Sample output Powerball Lottery](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C55-Project-55-Powerball-Lottery/powerball_lottery_sample_output.PNG)
