Trick Questions
========================================================

The 54 questions in this program have been specifically crafted so that their answers are simple, obvious, and misleading.

Sample Output
========================================================

![Sample output Trick-Questions](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C78-Project-78-Trick-Questions/trickquestions_sample_output.PNG)
