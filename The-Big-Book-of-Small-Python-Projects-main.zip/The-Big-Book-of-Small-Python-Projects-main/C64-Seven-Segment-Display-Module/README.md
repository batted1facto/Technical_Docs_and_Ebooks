Seven-Segment Display Module
========================================================

Through different combinations of seven line-shaped segments in an LCD, a seven-segment display can represent the digits 0 through 9. 

Sample Output
========================================================

![Sample output Seven-Segment Display Module)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C64-Seven-Segment-Display-Module/sevseg_sample_output.PNG)
