import sevseg

myNumber = sevseg.getSevSegStr(3.14159)

print(myNumber)
