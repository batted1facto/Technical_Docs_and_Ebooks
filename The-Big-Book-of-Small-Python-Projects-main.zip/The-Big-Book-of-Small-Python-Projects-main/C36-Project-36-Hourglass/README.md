Hourglass
========================================================

This visualization program has a rough physics engine that simulates sand falling through the small aperture of an hourglass.

Sample Output
========================================================

![Sample output Hourglass](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C36-Project-36-Hourglass/hourglass_sample_output.PNG)

