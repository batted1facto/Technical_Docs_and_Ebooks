Water Bucket Puzzle
========================================================


Sample Output
========================================================

![Sample output Water Bucket Puzzle](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C81-Project-81-Water-Bucket-Puzzle/waterbucket_sample_output.PNG)
