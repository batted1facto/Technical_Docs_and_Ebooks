Hungry Robots
========================================================

The x- and y- Cartesian coordinates that represent positions in this game allow us to use math to determine the direction in which the robots should move.

Sample Output
========================================================

![Sample output Hungry Robots](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C37-Project-37-Hungry-Robots/hungryrobots_sample_output.PNG)

