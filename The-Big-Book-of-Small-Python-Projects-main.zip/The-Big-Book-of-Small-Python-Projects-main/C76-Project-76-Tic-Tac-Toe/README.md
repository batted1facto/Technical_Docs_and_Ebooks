Tic-Tac-Toe
========================================================

Tic-tac-toe is a classic pencil-and-paper game played on a 3 × 3 grid. Players take turns placing their X or O marks, trying to get three in a row. 

Sample Output
========================================================

![Sample output Tic-Tac-Toe](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C76-Project-76-Tic-Tac-Toe/tictactoe_sample_output.PNG)
