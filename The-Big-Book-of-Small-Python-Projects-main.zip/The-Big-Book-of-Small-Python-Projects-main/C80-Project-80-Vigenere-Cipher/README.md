Vigenère Cipher
========================================================

The so-called Vigenère key is a word, or even a random series of letters. Each letter represents a number by which to shift the letter in the message.

Sample Output
========================================================

![Sample output Vigenère Cipher](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C80-Project-80-Vigenere-Cipher/vigenerecipher_sample_output.PNG)
