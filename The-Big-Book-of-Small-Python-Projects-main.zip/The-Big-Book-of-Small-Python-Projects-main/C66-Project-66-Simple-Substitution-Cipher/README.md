Simple Substitution Cipher
========================================================

The Simple Substitution Cipher substitutes one letter for another. 

Sample Output
========================================================

![Sample output Simple Substitution Cipher)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C66-Project-66-Simple-Substitution-Cipher/simplesubcipher_sample_output.PNG)
