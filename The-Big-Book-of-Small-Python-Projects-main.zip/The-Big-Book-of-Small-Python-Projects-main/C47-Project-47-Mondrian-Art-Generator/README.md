Mondrian Art Generator
========================================================

This program generates random paintings that follow Mondrian’s style. You can find out more about Piet Mondrian at https://en.wikipedia.org/wiki/ Piet_Mondrian.


Sample Output
========================================================

![Sample output Mondrian Art Generator](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C47-Project-47-Mondrian-Art-Generator/mondrian_sample_output.PNG)

