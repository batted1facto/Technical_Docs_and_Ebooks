Sound Mimic
========================================================

This program imports the playsound module, which can play sound files. 

On MacOS Yosemite and Windows 7 doesn't works.

Sample Output on Linux Mint
========================================================

![Sample output Sound Mimic)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C71-Project-71-Sound-Mimic/soundmimic_sample_output_on_Linux_Mint.png)


Error Output on Windows
========================================================

![Error output Sound Mimic)](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C71-Project-71-Sound-Mimic/soundmimic_error_output_on_Windows.PNG)
