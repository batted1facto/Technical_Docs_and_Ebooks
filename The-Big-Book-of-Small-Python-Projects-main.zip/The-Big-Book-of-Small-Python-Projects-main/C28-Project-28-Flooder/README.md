Flooder
========================================================
Flooder is a colorful game where a player tries to fill the board with a single color by changing the color of the tile in the upper-left corner.

Sample Output
========================================================

![Sample output Flooder](https://github.com/nihathalici/The-Big-Book-of-Small-Python-Projects/blob/main/C28-Project-28-Flooder/flooder_sample_output.PNG)
